"""Run inside Blender: blender -b -t 2 --python tools/convert_remaining_furniture.py -- /path/to/repo
Converts user-provided FBX and .blend sources, writes glb files, updates catalog.
"""
import bpy, sys, zipfile, tempfile, re, json, os
from pathlib import Path
root=Path(sys.argv[sys.argv.index('--')+1]).resolve() if '--' in sys.argv else Path.cwd()
out=root/'app/assets/3d/user_furniture';out.mkdir(parents=True,exist_ok=True)
source_names=['Mini-RPG-Bundle Part2.zip','medv-cafe.zip','Medieval_Inn_Beds.zip','3D Retro Medieval Fantasy Kit.zip']
blends=['medievaltavern.blend','medievalbenchesexport.blend','medievalstonestairs.blend']
records=[];errors=[]
def slug(s):return re.sub(r'[^a-z0-9]+','_',s.lower()).strip('_')[:75]
def clean():
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 for d in bpy.data.materials: bpy.data.materials.remove(d)
def convert(path,prefix):
 key=slug(prefix+'_'+path.stem); target=out/(key+'.glb')
 if target.exists():return
 try:
  clean()
  if path.suffix.lower()=='.fbx':bpy.ops.import_scene.fbx(filepath=str(path))
  else:
   with bpy.data.libraries.load(str(path),link=False) as (src,dst):dst.objects=list(src.objects)
   for obj in dst.objects:
    if obj and obj.name not in bpy.context.scene.objects:bpy.context.collection.objects.link(obj)
  meshes=[o for o in bpy.context.scene.objects if o.type=='MESH']
  if not meshes:raise ValueError('No meshes')
  bpy.ops.object.select_all(action='DESELECT')
  for o in meshes:o.select_set(True)
  bpy.context.view_layer.objects.active=meshes[0]
  bpy.ops.export_scene.gltf(filepath=str(target),export_format='GLB',use_selection=True,export_apply=True)
  if target.stat().st_size<500:raise ValueError('Export too small')
  records.append((key,prefix+' / '+path.stem))
 except Exception as e:errors.append((str(path),str(e)));print('FAILED',path,e)
with tempfile.TemporaryDirectory() as tmp:
 tmp=Path(tmp)
 for arch in source_names:
  p=root/arch
  if not p.exists():print('MISSING',p);continue
  d=tmp/slug(arch);d.mkdir()
  with zipfile.ZipFile(p) as z:
   for member in z.infolist():
    dest=(d/member.filename).resolve()
    if not dest.is_relative_to(d.resolve()):continue
    if member.is_dir():continue
    # Preserve adjacent image textures so Blender can resolve FBX references.
    # FBX preferred over duplicate Blend in Mini-RPG
    if arch.startswith('Mini-RPG') and Path(member.filename).suffix.lower()=='.blend':continue
    dest.parent.mkdir(parents=True,exist_ok=True)
    with z.open(member) as src,open(dest,'wb') as dst:
     import shutil;shutil.copyfileobj(src,dst)
  files=sorted(d.rglob('*.fbx'))
  if not files:files=sorted(d.rglob('*.blend'))
  for file in files:convert(file,slug(arch))
 for name in blends:
  p=root/name
  if p.exists():convert(p,'standalone')
 if (root/'bed.fbx').exists():convert(root/'bed.fbx','standalone')
cat=root/'app/3dmap/gltf_catalog.js'
if cat.exists():
 content=cat.read_text(encoding='utf8')
 # Add standalone IIFE to avoid altering preexisting catalog definitions.
 marker='/* AUTO-IMPORTED USER FURNITURE START */'
 if marker in content:content=content.split(marker)[0].rstrip()+'\n'
 lines=[marker,'(function(g){"use strict";var c=g.DND3DAssetCatalog,n=g.DND3DAssetNames;if(!c||!n)return;']
 for key,title in records:
  identifier='UserConverted_'+key
  item={'id':identifier,'name':title,'nameRus':title,'path':'./app/assets/3d/user_furniture/'+key+'.glb','category':'furniture','scale':1}
  lines.append('if(!c['+json.dumps(identifier)+']){c['+json.dumps(identifier)+']='+json.dumps(item,ensure_ascii=False)+';n.push('+json.dumps(identifier)+');}')
 lines.append('})(window);');content+='\n'.join(lines)+'\n'
 cat.write_text(content,encoding='utf8')
(root/'FURNITURE_CONVERSION_REPORT.json').write_text(json.dumps({'converted':records,'errors':errors},ensure_ascii=False,indent=2),encoding='utf8')
print('Converted',len(records),'failed',len(errors))
